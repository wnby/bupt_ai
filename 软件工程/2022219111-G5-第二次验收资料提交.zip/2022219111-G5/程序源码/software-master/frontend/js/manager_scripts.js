// 定义图表颜色
const chartColors = [
    'rgba(255, 99, 132, 0.8)',
    'rgba(54, 162, 235, 0.8)',
    'rgba(255, 206, 86, 0.8)',
    'rgba(75, 192, 192, 0.8)',
    'rgba(153, 102, 255, 0.8)'
];

// 获取统计数据
async function fetchStatistics() {
    try {
        const response = await fetch('http://127.0.0.1:8000/api/make_excel/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data = await response.json();
        if (data.status === 'success') {
            renderCharts(data.data);
            populateTable(data.data);
        } else {
            console.error('Failed to fetch statistics:', data.message);
        }
    } catch (error) {
        console.error('Error fetching statistics:', error);
    }
}

// 渲染所有图表
function renderCharts(data) {
    renderLineChart(data);
    renderPieChart('switchCountPie', '开关次数', data.room_ids, data.switch_counts);
    renderPieChart('scheduleCountPie', '调度次数', data.room_ids, data.schedule_counts);
    renderPieChart('tempAdjustmentPie', '调温次数', data.room_ids, data.temperature_adjustment_counts);
    renderPieChart('fanSpeedPie', '调风次数', data.room_ids, data.fan_speed_adjustment_counts);
}

// 渲染折线图
function renderLineChart(data) {
    const ctx = document.getElementById('lineChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.room_ids.map(id => `房间${id}`),
            datasets: [
                {
                    label: '开关次数',
                    data: data.switch_counts,
                    borderColor: chartColors[0],
                    fill: false
                },
                {
                    label: '调度次数',
                    data: data.schedule_counts,
                    borderColor: chartColors[1],
                    fill: false
                },
                {
                    label: '调温次数',
                    data: data.temperature_adjustment_counts,
                    borderColor: chartColors[2],
                    fill: false
                },
                {
                    label: '调风次数',
                    data: data.fan_speed_adjustment_counts,
                    borderColor: chartColors[3],
                    fill: false
                },
                {
                    label: '详单条数',
                    data: data.detail_counts,
                    borderColor: chartColors[4],
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: '房间使用统计数据'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// 渲染饼图
function renderPieChart(canvasId, title, labels, data) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels.map(id => `房间${id}`),
            datasets: [{
                data: data,
                backgroundColor: chartColors
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: title
                }
            }
        }
    });
}

// 填充数据表格
function populateTable(data) {
    const tbody = document.querySelector('#statsTable tbody');
    tbody.innerHTML = ''; // 清空现有内容

    for (let i = 0; i < data.room_ids.length; i++) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${data.room_ids[i]}</td>
            <td>${data.switch_counts[i]}</td>
            <td>${data.schedule_counts[i]}</td>
            <td>${data.detail_counts[i]}</td>
            <td>${data.temperature_adjustment_counts[i]}</td>
            <td>${data.fan_speed_adjustment_counts[i]}</td>
            <td>${data.request_durations[i]}</td>
            <td>${data.total_temp_changes[i].toFixed(2)}°C</td>
        `;
        tbody.appendChild(row);
    }
}

// 页面加载完成后获取数据
document.addEventListener('DOMContentLoaded', fetchStatistics);