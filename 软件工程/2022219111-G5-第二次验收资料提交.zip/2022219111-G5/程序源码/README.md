本程序是Django框架，老师想要看代码的话，可以切到以下路径看关键核心代码：

1.前端核心代码（html+css+js）

程序源码\software-master\frontend

2.后端核心代码

主要是两个文件：

核心后端：

程序源码\software-master\HotelSystem\UsingAC\models.py

Api接口合集：

程序源码\software-master\HotelSystem\UsingAC\views.py

3.运行方法

切到manage.py文件所在目录并运行：python manage.py runserver